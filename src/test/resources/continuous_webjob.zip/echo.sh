#!/bin/bash
while :
do
	echo "Hello"
	sleep 30
done
